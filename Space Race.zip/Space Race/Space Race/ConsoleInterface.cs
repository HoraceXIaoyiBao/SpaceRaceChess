﻿using System;
//DO NOT DELETE the two following using statements *********************************
using Game_Logic_Class;
using Object_Classes;


namespace Space_Race
{
    class Console_Class
    {
        /// <summary>
        /// Algorithm below currently plays only one game
        /// 
        /// when have this working correctly, add the abilty for the user to 
        /// play more than 1 game if they choose to do so.
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {      
             DisplayIntroductionMessage();

            /*                    
             Set up the board in Board class (Board.SetUpBoard)
             Determine number of players - initally play with 2 for testing purposes 
             Create the required players in Game Logic class
              and initialize players for start of a game             
             loop  until game is finished           
                call PlayGame in Game Logic class to play one round
                Output each player's details at end of round
             end loop
             Determine if anyone has won
             Output each player's details at end of the game
           */

            // use while cycle to realize  playing game multiple times
            while (true)
            {
                Board.SetUpBoard();

                SpaceRaceGame.InputNumberOfPlayers();//input and check if the input number is invalid;
                SpaceRaceGame.SetUpPlayers();// Initialized players

                Boolean if_first = true;//the flag for checking if it is first round

                while (true)
                {
                    Console.WriteLine("Press Enter to Play a Round ");
                    Console.ReadKey();//read "Enter"

                    if (if_first == true)//check if it is first time
                    {
                        Console.WriteLine("\n         First Round\n");
                        if_first = false;
                    }
                    else Console.WriteLine("\n         Next Round\n");

                    //play one round 
                    //false means play one round one time
                    //if it is true,it means play a single step one time
                    SpaceRaceGame.PlayOneRound(false);

                    //after running a round ,check if one of the players finished the game 
                    if (SpaceRaceGame.CheckIfFinished() == true) break;
                }

                //show who finish the game and the final situation
                SpaceRaceGame.ShowFinialMarks();

                //ask if user want to play next game
                //if not, break the while cycle
                if (IfPlayAgain() == false)
                    break;
            }
            PressEnter();

        }//end Main

   
        /// <summary>
        /// Display a welcome message to the console
        /// Pre:    none.
        /// Post:   A welcome message is displayed to the console.
        /// </summary>
       private static void DisplayIntroductionMessage()
        {
            Console.WriteLine("         Welcome to Space Race.\n");
        } //end DisplayIntroductionMessage

        //ask if user want to play again
        //if yes return true,else return false
       private static Boolean IfPlayAgain()
        {
            Console.WriteLine("Do you want to play again?(Y/N):");
            while (true)
            {
                string decision_to_play = Console.ReadLine();
                if (decision_to_play == "Y" || decision_to_play == "y")//if "y" or "Y" return ture
                    return true;
                else if (decision_to_play == "N" || decision_to_play == "n")//if "n" or "N" return false
                    return false;
                else Console.WriteLine("        Invalid input !(y/n):");//if user's input not a y/n/Y/N , ask to type again 
            }
        }//end IfPlayAgain

        /// <summary>
        /// Displays a prompt and waits for a keypress.
        /// Pre:  none
        /// Post: a key has been pressed.
        /// </summary>
        static void PressEnter()
        {
            Console.Write("\nPress Enter to terminate program ...");
            Console.ReadLine();
        } // end PressAny
        static void FinishedMessage()
        {
            Console.Write("\nThe following player(s) finished the game:\n");

            Console.ReadLine();
        } // end PressAny



    }//end Console class
}
